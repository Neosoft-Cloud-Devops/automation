__author__ = 'Oleg Butovich'
__copyright__ = '(c) Oleg Butovich 2013-2017'
__version__ = '1.0.3'
__licence__ = 'MIT'

from .core import *
